<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class Ns_FacebookPixel extends Module
{
    public function __construct()
    {
        $this->name = 'ns_facebookpixel';
        $this->tab = 'analytics_stats';
        $this->version = '1.0.0';
        $this->author = 'NdiagaSoft';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Facebook Pixel Integration');
        $this->description = $this->l('Integrate Facebook Pixel with your PrestaShop store for enhanced ad tracking and targeting.');

        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        return parent::install() &&
            $this->registerHook('header') &&            
            $this->registerHook('displayFooter') &&
            $this->createConfig();
    }

    public function uninstall()
    {
        return parent::uninstall() &&
            $this->unregisterHook('header') &&            
            $this->unregisterHook('displayFooter') &&
            $this->deleteConfig();
    }

    protected function createConfig()
    {
        Configuration::updateValue('NS_FB_PIXEL_ID', '');
        return true;
    }

    protected function deleteConfig()
    {
        Configuration::deleteByName('NS_FB_PIXEL_ID');
        return true;
    }

    public function getContent()
    {
        $output = null;

        if (Tools::isSubmit('submit' . $this->name)) {
            $pixel_id = Tools::getValue('NS_FB_PIXEL_ID');
            Configuration::updateValue('NS_FB_PIXEL_ID', $pixel_id);
            $output .= $this->displayConfirmation($this->l('Settings updated'));
        }

               $output.=$this->renderForm();
		       $output.='<br/>'.$this->display(__FILE__, 'advertizement.tpl');
			   
			    return $output;
    }

    protected function renderForm()
    {
        $fields_form = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs'
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('Facebook Pixel ID'),
                        'name' => 'NS_FB_PIXEL_ID',
                        'desc' => $this->l('Enter your Facebook Pixel ID.'),
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                ]
            ]
        ];

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submit' . $this->name;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name;
        $helper->tpl_vars = [
            'fields_value' => [
                'NS_FB_PIXEL_ID' => Tools::getValue('NS_FB_PIXEL_ID', Configuration::get('NS_FB_PIXEL_ID'))
            ],
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        ];

        return $helper->generateForm([$fields_form]);
    }

    public function hookHeader()
    {
        $pixel_id = Configuration::get('NS_FB_PIXEL_ID');
        if ($pixel_id) {
            $this->context->smarty->assign('fb_pixel_id', $pixel_id);
            return $this->display(__FILE__, 'views/templates/hook/pixel.tpl');
        }
    }
}
